self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil((async () => {
  await self.registration.unregister();
  const list = await self.clients.matchAll({ type: 'window' });
  list.forEach(c => { try { c.navigate(c.url); } catch (_) {} });
})()));
